import { useMemo, useState } from "react";
import { UploadCard } from "@/components/UploadCard";
import { Heatmap } from "@/components/Heatmap";
import { StatsPanel } from "@/components/StatsPanel";
import { analyze, parseTimes } from "@/lib/predictive";
import { Brain, Sparkles, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";

const Index = () => {
  const [allTimes, setAllTimes] = useState<string[]>([]);

  const handleNewTimes = (incoming: string[]) => {
    // Aprendizado contínuo: prepende novos no topo (mais recentes) e mantém únicos por sequência
    setAllTimes((prev) => [...incoming, ...prev]);
  };

  const result = useMemo(() => analyze(parseTimes(allTimes)), [allTimes]);

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="border-b border-border bg-[image:var(--gradient-panel)]">
        <div className="container flex flex-col gap-2 py-8">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[image:var(--gradient-hero)]">
              <Brain className="h-5 w-5 text-primary-foreground" />
            </div>
            <h1 className="text-2xl font-extrabold tracking-tight md:text-3xl">
              Painel Preditivo de Horários
            </h1>
          </div>
          <p className="max-w-2xl text-sm text-muted-foreground">
            OCR automático de imagens com horários HH:MM, matriz hora × minuto ponderada,
            heatmap colorido e previsão dos próximos horários mais prováveis.
          </p>
        </div>
      </header>

      <main className="container space-y-6 py-8">
        <UploadCard onTimes={handleNewTimes} />

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Sparkles className="h-4 w-4 text-accent" />
            {allTimes.length > 0
              ? `${allTimes.length} horários no banco estatístico`
              : "Envie uma imagem para iniciar a análise"}
          </div>
          {allTimes.length > 0 && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setAllTimes([])}
              className="text-muted-foreground hover:text-destructive"
            >
              <Trash2 className="mr-2 h-4 w-4" /> Limpar histórico
            </Button>
          )}
        </div>

        {allTimes.length > 0 && (
          <>
            <Heatmap result={result} />
            <StatsPanel result={result} />

            <details className="rounded-2xl border border-border bg-card p-4 text-sm">
              <summary className="cursor-pointer font-semibold text-foreground">
                Ver horários extraídos ({allTimes.length})
              </summary>
              <div className="mt-3 flex flex-wrap gap-2">
                {allTimes.map((t, i) => (
                  <span
                    key={`${t}-${i}`}
                    className="rounded-md bg-secondary px-2 py-1 font-mono text-xs text-foreground"
                  >
                    {t}
                  </span>
                ))}
              </div>
            </details>
          </>
        )}
      </main>

      <footer className="border-t border-border py-6 text-center text-xs text-muted-foreground">
        Análise estatística baseada em peso temporal — quanto mais escuro no heatmap,
        maior a probabilidade histórica.
      </footer>
    </div>
  );
};

export default Index;
