// Engine de análise preditiva sobre horários HH:MM

export type TimeEntry = { hour: number; minute: number; raw: string };

// Faixas de minuto: 5,10,15,...,55,60 (60 = minutos 56-59 ou 00 dependendo do agrupamento solicitado)
// Conforme o brief: 07:41 → grupo 40, 06:59 → grupo 60, 03:14 → grupo 15
// Regra: agrupar pelo próximo múltiplo de 5 (ceil), mapeando 0 → 5 e 56-59 → 60.
export const MINUTE_BUCKETS = [5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60];

export function bucketMinute(min: number): number {
  if (min === 0) return 5;
  const b = Math.ceil(min / 5) * 5;
  return b === 0 ? 5 : Math.min(60, b);
}

export function parseTimes(raw: string[]): TimeEntry[] {
  const out: TimeEntry[] = [];
  for (const t of raw) {
    const m = /^([0-1][0-9]|2[0-3]):([0-5][0-9])$/.exec(t.trim());
    if (!m) continue;
    out.push({ hour: parseInt(m[1], 10), minute: parseInt(m[2], 10), raw: t.trim() });
  }
  return out;
}

/**
 * Peso temporal: registros mais recentes têm mais peso.
 * Os primeiros índices da lista são considerados os MAIS recentes
 * (cards normalmente listam o mais novo no topo / esquerda).
 * - índices 0-9   → peso 3
 * - índices 10-19 → peso 2
 * - resto         → peso 1
 */
export function weightFor(index: number): number {
  if (index < 10) return 3;
  if (index < 20) return 2;
  return 1;
}

export type HeatCell = {
  hour: number;
  bucket: number;
  count: number;
  weighted: number;
  probability: number; // 0..1 dentro do dataset ponderado
};

export type AnalysisResult = {
  totalEntries: number;
  matrix: HeatCell[][]; // [bucketIndex][hour]
  maxWeighted: number;
  hourRanking: { hour: number; weighted: number; count: number }[];
  bucketRanking: { bucket: number; weighted: number; count: number }[];
  hotZones: HeatCell[]; // top 5
  predictions: { time: string; score: number; confidence: number }[]; // próximos prováveis
  confidence: number; // 0..100
  patterns: string[];
};

export function analyze(entries: TimeEntry[]): AnalysisResult {
  const hours = Array.from({ length: 24 }, (_, i) => i); // 0..23
  // matrix[bucketIdx][hour]
  const matrix: HeatCell[][] = MINUTE_BUCKETS.map((bucket) =>
    hours.map((hour) => ({ hour, bucket, count: 0, weighted: 0, probability: 0 })),
  );

  let totalWeighted = 0;
  entries.forEach((e, idx) => {
    const w = weightFor(idx);
    const bIdx = MINUTE_BUCKETS.indexOf(bucketMinute(e.minute));
    if (bIdx === -1) return;
    const cell = matrix[bIdx][e.hour];
    cell.count += 1;
    cell.weighted += w;
    totalWeighted += w;
  });

  let maxWeighted = 0;
  matrix.forEach((row) =>
    row.forEach((c) => {
      if (c.weighted > maxWeighted) maxWeighted = c.weighted;
      c.probability = totalWeighted ? c.weighted / totalWeighted : 0;
    }),
  );

  // Rankings
  const hourAgg = hours.map((h) => {
    let weighted = 0;
    let count = 0;
    for (const row of matrix) {
      weighted += row[h].weighted;
      count += row[h].count;
    }
    return { hour: h, weighted, count };
  });
  const hourRanking = [...hourAgg].sort((a, b) => b.weighted - a.weighted);

  const bucketAgg = MINUTE_BUCKETS.map((bucket, i) => {
    let weighted = 0;
    let count = 0;
    for (const c of matrix[i]) {
      weighted += c.weighted;
      count += c.count;
    }
    return { bucket, weighted, count };
  });
  const bucketRanking = [...bucketAgg].sort((a, b) => b.weighted - a.weighted);

  // Hot zones: top 5 células
  const flat: HeatCell[] = [];
  matrix.forEach((row) => row.forEach((c) => flat.push(c)));
  const hotZones = [...flat]
    .filter((c) => c.weighted > 0)
    .sort((a, b) => b.weighted - a.weighted)
    .slice(0, 5);

  // Previsão dos próximos prováveis: combinar top hours x top buckets
  // Score = peso da célula + bônus se hora e bucket estão entre os top
  const topHours = new Set(hourRanking.slice(0, 6).map((h) => h.hour));
  const topBuckets = new Set(bucketRanking.slice(0, 4).map((b) => b.bucket));
  const predictionPool = flat
    .map((c) => {
      const hourBonus = topHours.has(c.hour) ? 1.4 : 1;
      const bucketBonus = topBuckets.has(c.bucket) ? 1.4 : 1;
      const score = c.weighted * hourBonus * bucketBonus;
      return { cell: c, score };
    })
    .sort((a, b) => b.score - a.score);

  const seen = new Set<string>();
  const predictions: { time: string; score: number; confidence: number }[] = [];
  const maxScore = predictionPool[0]?.score || 1;
  for (const p of predictionPool) {
    if (predictions.length >= 6) break;
    // Representar o bucket como minuto exibido: bucket 60 → :55-:59 (mostrar :58), demais → bucket-2
    const displayMin =
      p.cell.bucket === 60 ? 58 : Math.max(0, p.cell.bucket - 2);
    const time = `${String(p.cell.hour).padStart(2, "0")}:${String(displayMin).padStart(2, "0")}`;
    if (seen.has(time)) continue;
    seen.add(time);
    predictions.push({
      time,
      score: p.score,
      confidence: Math.round((p.score / maxScore) * 100),
    });
  }

  // Detecção de padrões
  const patterns: string[] = [];
  if (entries.length >= 2) {
    // Intervalo médio entre registros consecutivos (em minutos)
    const diffs: number[] = [];
    for (let i = 0; i < entries.length - 1; i++) {
      const a = entries[i].hour * 60 + entries[i].minute;
      const b = entries[i + 1].hour * 60 + entries[i + 1].minute;
      let d = a - b;
      if (d < 0) d += 24 * 60;
      diffs.push(d);
    }
    const avg = diffs.reduce((s, x) => s + x, 0) / diffs.length;
    patterns.push(`Intervalo médio entre eventos: ~${avg.toFixed(1)} min`);

    // Aceleração: últimos 5 vs anteriores
    if (diffs.length >= 6) {
      const recent = diffs.slice(0, 5).reduce((s, x) => s + x, 0) / 5;
      const older = diffs.slice(5).reduce((s, x) => s + x, 0) / (diffs.length - 5);
      if (recent < older * 0.75) patterns.push("⚡ Aceleração detectada nos últimos eventos");
      else if (recent > older * 1.25) patterns.push("🐢 Desaceleração nos últimos eventos");
      else patterns.push("➡️ Cadência estável");
    }
  }
  if (hotZones[0]) {
    const z = hotZones[0];
    patterns.push(
      `🔥 Zona quente principal: ${String(z.hour).padStart(2, "0")}h faixa :${String(z.bucket).padStart(2, "0")}`,
    );
  }

  // Confiança estatística — função do volume e da concentração
  const concentration = maxWeighted / (totalWeighted || 1); // 0..1
  const volumeScore = Math.min(1, entries.length / 30);
  const confidence = Math.round((volumeScore * 0.5 + concentration * 0.5) * 100);

  return {
    totalEntries: entries.length,
    matrix,
    maxWeighted,
    hourRanking,
    bucketRanking,
    hotZones,
    predictions,
    confidence,
    patterns,
  };
}

// Gera cor HSL para o heatmap: amarelo claro → laranja → vermelho → vermelho escuro
export function heatColor(intensity: number): string {
  // intensity 0..1
  if (intensity <= 0) return "hsl(48 95% 96%)"; // quase branco/amarelo claríssimo
  // Hue: 50 (amarelo) → 0 (vermelho)
  const hue = 50 - intensity * 50;
  // Saturação alta
  const sat = 90;
  // Luminosidade: 88% (muito claro) → 28% (vermelho escuro)
  const light = 88 - intensity * 60;
  return `hsl(${hue.toFixed(1)} ${sat}% ${light.toFixed(1)}%)`;
}