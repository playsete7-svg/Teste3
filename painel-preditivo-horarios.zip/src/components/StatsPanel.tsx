import { AnalysisResult } from "@/lib/predictive";
import { Flame, Target, TrendingUp, Activity, Clock } from "lucide-react";

export function StatsPanel({ result }: { result: AnalysisResult }) {
  return (
    <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
      <Card title="Confiança estatística" icon={<Activity className="h-4 w-4" />}>
        <div className="flex items-end gap-2">
          <span className="text-4xl font-extrabold text-foreground">{result.confidence}</span>
          <span className="mb-1 text-sm text-muted-foreground">/ 100</span>
        </div>
        <div className="mt-3 h-2 overflow-hidden rounded-full bg-secondary">
          <div
            className="h-full bg-[image:var(--gradient-hero)]"
            style={{ width: `${result.confidence}%` }}
          />
        </div>
        <p className="mt-2 text-xs text-muted-foreground">
          {result.totalEntries} registros analisados
        </p>
      </Card>

      <Card title="Próximos horários prováveis" icon={<Target className="h-4 w-4" />}>
        <ul className="space-y-2">
          {result.predictions.slice(0, 5).map((p, i) => (
            <li key={p.time} className="flex items-center justify-between rounded-lg bg-secondary/50 px-3 py-2">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-muted-foreground">#{i + 1}</span>
                <span className="font-mono text-base font-bold text-foreground">{p.time}</span>
              </div>
              <span className="text-xs font-semibold text-accent">{p.confidence}%</span>
            </li>
          ))}
          {!result.predictions.length && (
            <li className="text-sm text-muted-foreground">Sem dados suficientes.</li>
          )}
        </ul>
      </Card>

      <Card title="Padrões detectados" icon={<TrendingUp className="h-4 w-4" />}>
        <ul className="space-y-2 text-sm text-foreground/90">
          {result.patterns.map((p, i) => (
            <li key={i} className="rounded-lg bg-secondary/50 px-3 py-2">{p}</li>
          ))}
          {!result.patterns.length && (
            <li className="text-sm text-muted-foreground">Envie mais dados para detecção.</li>
          )}
        </ul>
      </Card>

      <Card title="Top horas (X)" icon={<Clock className="h-4 w-4" />}>
        <ol className="space-y-1.5 text-sm">
          {result.hourRanking.slice(0, 5).filter((h) => h.weighted > 0).map((h, i) => (
            <li key={h.hour} className="flex items-center justify-between">
              <span className="text-muted-foreground">#{i + 1}</span>
              <span className="font-mono font-bold text-foreground">{String(h.hour).padStart(2, "0")}h</span>
              <span className="text-xs text-accent">peso {h.weighted}</span>
            </li>
          ))}
        </ol>
      </Card>

      <Card title="Top minutos (Y)" icon={<Clock className="h-4 w-4" />}>
        <ol className="space-y-1.5 text-sm">
          {result.bucketRanking.slice(0, 5).filter((b) => b.weighted > 0).map((b, i) => (
            <li key={b.bucket} className="flex items-center justify-between">
              <span className="text-muted-foreground">#{i + 1}</span>
              <span className="font-mono font-bold text-foreground">:{String(b.bucket).padStart(2, "0")}</span>
              <span className="text-xs text-accent">peso {b.weighted}</span>
            </li>
          ))}
        </ol>
      </Card>

      <Card title="Zonas quentes" icon={<Flame className="h-4 w-4" />}>
        <ol className="space-y-1.5 text-sm">
          {result.hotZones.map((z, i) => (
            <li key={`${z.hour}-${z.bucket}`} className="flex items-center justify-between">
              <span className="text-muted-foreground">#{i + 1}</span>
              <span className="font-mono font-bold text-foreground">
                {String(z.hour).padStart(2, "0")}:{String(z.bucket).padStart(2, "0")}
              </span>
              <span className="text-xs text-primary">{(z.probability * 100).toFixed(1)}%</span>
            </li>
          ))}
          {!result.hotZones.length && (
            <li className="text-sm text-muted-foreground">—</li>
          )}
        </ol>
      </Card>
    </div>
  );
}

function Card({
  title,
  icon,
  children,
}: {
  title: string;
  icon: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <div className="rounded-2xl border border-border bg-[image:var(--gradient-panel)] p-5">
      <div className="mb-3 flex items-center gap-2 text-sm font-semibold uppercase tracking-wider text-muted-foreground">
        <span className="text-accent">{icon}</span>
        {title}
      </div>
      {children}
    </div>
  );
}