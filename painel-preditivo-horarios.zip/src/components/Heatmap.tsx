import { AnalysisResult } from "@/lib/predictive";
import { heatColor, MINUTE_BUCKETS } from "@/lib/predictive";

type Props = { result: AnalysisResult };

export function Heatmap({ result }: Props) {
  const hours = Array.from({ length: 24 }, (_, i) => i);
  const max = result.maxWeighted || 1;

  return (
    <div className="rounded-2xl border border-border bg-card p-5 shadow-[var(--shadow-glow)]">
      <div className="mb-4 flex items-end justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-foreground">
            Probabilidade por Horário
          </h2>
          <p className="text-sm text-muted-foreground">Baseado nos últimos resultados</p>
        </div>
        <Legend />
      </div>

      <div className="overflow-x-auto">
        <div className="min-w-[640px]">
          {/* Header de horas */}
          <div
            className="grid gap-[2px] pl-12"
            style={{ gridTemplateColumns: `repeat(24, minmax(0, 1fr))` }}
          >
            {hours.map((h) => (
              <div
                key={h}
                className="text-center text-[10px] font-medium text-muted-foreground"
              >
                {String(h).padStart(2, "0")}h
              </div>
            ))}
          </div>

          {/* Linhas por bucket de minuto */}
          <div className="mt-2 space-y-[2px]">
            {MINUTE_BUCKETS.map((bucket, bIdx) => (
              <div key={bucket} className="flex items-center gap-2">
                <div className="w-10 shrink-0 text-right text-[11px] font-semibold text-muted-foreground">
                  :{String(bucket).padStart(2, "0")}
                </div>
                <div
                  className="grid flex-1 gap-[2px]"
                  style={{ gridTemplateColumns: `repeat(24, minmax(0, 1fr))` }}
                >
                  {hours.map((h) => {
                    const cell = result.matrix[bIdx][h];
                    const intensity = cell.weighted / max;
                    return (
                      <div
                        key={h}
                        title={`${String(h).padStart(2, "0")}:${String(bucket).padStart(2, "0")} — ${cell.count} ocorr. (peso ${cell.weighted})`}
                        className="aspect-square rounded-[3px] transition-transform hover:scale-110 hover:ring-2 hover:ring-accent/70"
                        style={{
                          backgroundColor: heatColor(intensity),
                          opacity: cell.weighted === 0 ? 0.25 : 1,
                        }}
                      >
                        {cell.count > 0 && intensity > 0.55 ? (
                          <div className="flex h-full items-center justify-center text-[9px] font-bold text-background">
                            {cell.count}
                          </div>
                        ) : null}
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <p className="mt-4 text-center text-xs italic text-muted-foreground">
        Quanto mais escuro, maior a probabilidade histórica
      </p>
    </div>
  );
}

function Legend() {
  const stops = [0.05, 0.25, 0.5, 0.75, 1];
  return (
    <div className="flex items-center gap-2">
      <span className="text-[11px] font-medium text-muted-foreground">Ocorrências</span>
      <div className="flex h-4 overflow-hidden rounded-full border border-border">
        {stops.map((s) => (
          <div key={s} className="w-5" style={{ backgroundColor: heatColor(s) }} />
        ))}
      </div>
      <div className="flex flex-col text-[9px] text-muted-foreground">
        <span>baixa → alta</span>
      </div>
    </div>
  );
}