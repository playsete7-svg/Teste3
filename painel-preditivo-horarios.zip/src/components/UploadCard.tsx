import { useRef, useState } from "react";
import { Upload, Loader2, ImagePlus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

type Props = {
  onTimes: (times: string[]) => void;
};

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(r.result as string);
    r.onerror = reject;
    r.readAsDataURL(file);
  });
}

export function UploadCard({ onTimes }: Props) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [loading, setLoading] = useState(false);
  const [preview, setPreview] = useState<string | null>(null);

  const handleFile = async (file: File) => {
    if (!file.type.startsWith("image/")) {
      toast.error("Envie uma imagem (PNG/JPG).");
      return;
    }
    setLoading(true);
    try {
      const dataUrl = await fileToBase64(file);
      setPreview(dataUrl);

      const { data, error } = await supabase.functions.invoke("extract-times", {
        body: { imageBase64: dataUrl },
      });

      if (error) {
        const msg = (error as any)?.context?.body
          ? await (error as any).context.text().catch(() => "")
          : error.message;
        if (msg?.includes("429")) toast.error("Muitas requisições — aguarde alguns segundos.");
        else if (msg?.includes("402")) toast.error("Créditos insuficientes na sua workspace.");
        else toast.error("Falha ao analisar imagem.");
        console.error(error);
        return;
      }

      const times: string[] = data?.times ?? [];
      if (!times.length) {
        toast.warning("Nenhum horário identificado na imagem.");
        return;
      }
      toast.success(`${times.length} horário(s) extraído(s).`);
      onTimes(times);
    } catch (e) {
      console.error(e);
      toast.error("Erro inesperado ao processar a imagem.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="rounded-2xl border border-border bg-card p-6">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h3 className="text-lg font-bold text-foreground">Enviar imagem de histórico</h3>
          <p className="text-sm text-muted-foreground">
            Faça upload de uma captura com horários HH:MM. O OCR é automático.
          </p>
        </div>
        <Button
          onClick={() => inputRef.current?.click()}
          disabled={loading}
          className="bg-[image:var(--gradient-hero)] text-primary-foreground hover:opacity-90"
        >
          {loading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Analisando...
            </>
          ) : (
            <>
              <Upload className="mr-2 h-4 w-4" /> Selecionar imagem
            </>
          )}
        </Button>
      </div>

      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) handleFile(f);
          e.currentTarget.value = "";
        }}
      />

      <div
        onDragOver={(e) => e.preventDefault()}
        onDrop={(e) => {
          e.preventDefault();
          const f = e.dataTransfer.files?.[0];
          if (f) handleFile(f);
        }}
        className="mt-4 flex min-h-[180px] items-center justify-center rounded-xl border-2 border-dashed border-border bg-secondary/30 p-4 text-center"
      >
        {preview ? (
          <img
            src={preview}
            alt="Pré-visualização do histórico enviado"
            className="max-h-48 rounded-lg border border-border object-contain"
          />
        ) : (
          <div className="flex flex-col items-center gap-2 text-muted-foreground">
            <ImagePlus className="h-8 w-8" />
            <span className="text-sm">Arraste uma imagem aqui ou clique no botão</span>
          </div>
        )}
      </div>
    </div>
  );
}